require('dotenv').config();
const express = require('express');
const path = require('path');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const apiRoutes = require('./app_api/routes/index');
const app = express();
const cors = require('cors');

const passport = require("passport")

require('./app_api/config/db');
require('./app_api/config/passport');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')))
app.use(passport.initialize());

// allow cors
app.use(cors({
    origin: 'http://localhost:4200',  
    methods: 'GET,POST,PUT,DELETE,PATCH',
    allowedHeaders: 'Content-Type,Authorization'
}));


app.use('/api',apiRoutes);


app.use((err, req, res, next)=>{
    console.log(err)
    if(err.name==="UnauthorizedError"){
        res.status(401)
        .json({"message": err.name+": " + err.message})
    }
})


const PORT = process.env.PORT || 9000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});

module.exports = app;
