const Reservation = require('../models/reservations');
const { getUser } = require('../utils/user');

const createReservation = async (req, res) => {

    getUser(req, res, async () => {
        try {
            const { tripCode, userEmail, guests } = req.body;
            if (!tripCode || !userEmail || !guests) {
                return res.status(400).json({ message: "All fields are required" });
            }

            const reservation = new Reservation({
                tripCode,
                userEmail,
                guests,
                status: "Pending"
            });

            await reservation.save();
            res.status(201).json({ message: "Reservation successful", reservation });
        } catch (error) {
            res.status(400).json({ message: "Failed to create reservation", error: error.message });
        }
    });
};

const getUserReservations = async (req, res) => {
    getUser(req, res, async () => {
        try {
            if (req.auth.role !== "admin") {
                return res.status(401).json({ "message": "Don't have enough previlidges" })
            }
            const reservations = await Reservation.aggregate([
                {
                    $lookup: {
                        from: "trips",
                        localField: "tripCode",
                        foreignField: "code",
                        as: "tripDetails"
                    }
                },
                {
                    $unwind: "$tripDetails"
                }
            ]);

            res.status(200).json(reservations);
        } catch (error) {
            console.error("Error fetching reservations:", error);
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

const getAllReservations = async (req, res) => {
    getUser(req, res, async () => {
        try {
            const reservations = await Reservation.aggregate([
                {
                    $match: { userEmail: req.params.userEmail }
                },
                {
                    $lookup: {
                        from: "trips",
                        localField: "tripCode",
                        foreignField: "code",
                        as: "tripDetails"
                    }
                },
                {
                    $unwind: "$tripDetails"
                }
            ]);

            res.status(200).json(reservations);
        } catch (error) {
            console.error("Error fetching reservations:", error);
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

const getReservationById = async (req, res) => {
    getUser(req, res, async () => {
        try {
            const reservation = await Reservation.findById(req.params.id);
            if (!reservation) {
                return res.status(404).json({ message: "Reservation not found" });
            }
            res.status(200).json(reservation);
        } catch (error) {
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

const updateReservation = async (req, res) => {
    getUser(req, res, async () => {
        try {
            const { status } = req.body;
            const reservation = await Reservation.findByIdAndUpdate(
                req.params.id,
                { status },
                { new: true }
            );
            if (!reservation) {
                return res.status(404).json({ message: "Reservation not found" });
            }
            res.status(200).json({ message: "Reservation updated", reservation });
        } catch (error) {
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

const deleteReservation = async (req, res) => {
    getUser(req, res, async () => {
        try {
            const reservation = await Reservation.findByIdAndDelete(req.params.id);
            if (!reservation) {
                return res.status(404).json({ message: "Reservation not found" });
            }
            res.status(204).send();
        } catch (error) {
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};


const updateReservationStatus = async (req, res) => {
    getUser(req, res, async () => {
        try {
            // Check if user is an admin
            if (req.auth.role !== "admin") {
                return res.status(403).json({ message: "Forbidden: Admins only" });
            }

            const { status } = req.body;
            if (!["pending", "accepted", "cancelled"].includes(status)) {
                return res.status(400).json({ message: "Invalid status" });
            }

            const reservation = await Reservation.findByIdAndUpdate(
                req.params.id,
                { status },
                { new: true }
            );

            if (!reservation) {
                return res.status(404).json({ message: "Reservation not found" });
            }

            res.status(200).json({ message: "Reservation updated successfully", reservation });

        } catch (error) {
            console.error("Error updating reservation:", error);
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

module.exports = {
    createReservation,
    getUserReservations,
    getReservationById,
    updateReservation,
    deleteReservation,
    getAllReservations,
    updateReservationStatus
};
