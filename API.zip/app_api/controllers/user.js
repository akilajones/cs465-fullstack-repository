const User = require('../models/User');
const { getUser } = require('../utils/user');

const getUsers = async (req, res) => {
    getUser(req, res, async () => {
        try {
            if (req.auth.role !== "admin") {
                return res.status(401).json({ message: "Don't have enough privileges" });
            }

            // Exclude 'password', 'salt' and filter out admins
            const users = await User.find({ role: { $ne: 'admin' } })
                .select('-password -salt'); 

            res.status(200).json(users);
        } catch (error) {
            console.error("Error fetching users:", error);
            res.status(500).json({ message: "Server Error", error: error.message });
        }
    });
};

module.exports = {
    getUsers
};
