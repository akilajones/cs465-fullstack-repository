
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authentication');
const tripsController = require('../controllers/trip');
const reservationsController = require('../controllers/reservations');
const userController = require('../controllers/user');
var { expressjwt: jwt } = require("express-jwt");

const auth = jwt({
    secret: process.env.JWT_SECRET,
    userProperty: 'payload',
    algorithms: ["HS256"],
})

router.post('/register', authController.register);
router.post('/login', authController.login);

router.get('/trips', tripsController.tripsList);
router.get('/trips/:tripCode', tripsController.tripsFindByCode);
// protected routes
router.post('/trips', auth, tripsController.tripsAddTrip);
router.put('/trips/:tripCode', auth, tripsController.tripsUpdateTrip);
router.delete('/trips/:tripCode', auth, tripsController.tripsDeleteTrip);

router.post('/reservations', auth, reservationsController.createReservation);
router.get('/reservations/:userEmail', auth, reservationsController.getUserReservations);
router.get('/reservations/list-all', auth, reservationsController.getUserReservations);
router.patch('/reservations/:id', auth, reservationsController.updateReservationStatus);

router.get('/users', auth, userController.getUsers);
module.exports = router;
