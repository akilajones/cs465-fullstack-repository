const getUser = (req, res, callback) => {
    if (req.auth && req.auth._id) {
        callback(req, res);
    } else {
        res.status(401).json({ message: "Unauthorized access" });
    }
};



module.exports = {
    getUser
}