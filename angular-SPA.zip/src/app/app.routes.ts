import { Routes } from '@angular/router';

import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { TripDetailComponent } from './component/trip-detail/trip-detail.component';
import { ReservationsComponent } from './component/reservations/reservations.component';
import { authGuard } from './guards/auth.guard';
import { TravelComponent } from './component/travel/travel.component';
import { NewsComponent } from './component/news/news.component';
import { CheckoutComponent } from './component/checkout/checkout.component';
import { AboutComponent } from './component/about/about.component';
import { AdminComponent } from './component/admin/admin.component';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'news', component: NewsComponent },
  { path: 'trips/:tripCode', component: TripDetailComponent },
  { path: 'reservations', component: ReservationsComponent, canActivate: [authGuard] },
  { path: 'checkout/:tripCode', component: CheckoutComponent, canActivate: [authGuard] },
  { path: 'admin', component: AdminComponent, canActivate: [authGuard] },
  { path: 'about', component: AboutComponent },
  { path: 'admin', loadChildren: () => import('./component/admin/admin.routes').then(m => m.routes) },
  { path: '', component: TravelComponent, pathMatch: 'full' },
];

