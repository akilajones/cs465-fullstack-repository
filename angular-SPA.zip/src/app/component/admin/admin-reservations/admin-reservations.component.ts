import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Reservation } from '../../../models/reservation';
import { TripDataService } from '../../../services/trip-data.service';
import { AuthenticationService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-reservations',
  imports: [CommonModule],
  templateUrl: './admin-reservations.component.html',
  styleUrl: './admin-reservations.component.css'
})
export class AdminReservationsComponent implements OnInit {
  reservations: Reservation[] = [];

  constructor(private dataService: TripDataService, private authService: AuthenticationService) { }

  ngOnInit(): void {
    this.loadReservations();
  }

  loadReservations() {
    const token = this.authService.getToken() || ""
    this.dataService.getReservations(token).subscribe({
      next: (data) => {
        this.reservations = data;
      },
      error: (error) => {
        console.error('Error fetching reservations:', error);
      }
    }
    );
  }

  updateReservation(reservationId: string, status: string) {
    const token = this.authService.getToken() || ""
    this.dataService.updateReservationStatus(reservationId, status, token).subscribe({
      next: () => {
        this.reservations = this.reservations.map(reservation =>
          reservation._id === reservationId ? { ...reservation, status } : reservation
        );
      },

      error: (error) => {
        console.error('Error updating reservation:', error);
      }
    }


    );
  }
}
