import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTripFormComponent } from './admin-trip-form.component';

describe('AdminTripFormComponent', () => {
  let component: AdminTripFormComponent;
  let fixture: ComponentFixture<AdminTripFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [AdminTripFormComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminTripFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
