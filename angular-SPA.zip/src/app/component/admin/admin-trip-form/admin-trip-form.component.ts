import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { Trip } from '../../../models/trip';
import { TripDataService } from '../../../services/trip-data.service';
import { CommonModule } from '@angular/common';
import { AuthenticationService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-trip-form',
  imports: [CommonModule, ReactiveFormsModule, RouterModule],
  templateUrl: './admin-trip-form.component.html',
  styleUrl: './admin-trip-form.component.css'
})
export class AdminTripFormComponent implements OnInit {
  tripForm!: FormGroup;
  tripCode!: string | null;
  constructor(
    private fb: FormBuilder,
    private tripService: TripDataService,
    private route: ActivatedRoute,
    private router: Router,
    private authService: AuthenticationService
  ) { }

  ngOnInit(): void {
    const code = this.route.snapshot.paramMap.get('id');
    this.tripCode = code === "new" ? null : code;

    this.tripForm = this.fb.group({
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: [''],
      start: [''],
      resort: [''],
      perPerson: [''],
      image: [''],
      description: ['']
    });

    if (this.tripCode) {
      this.tripService.getTripByCode(this.tripCode).subscribe(trip => {
        const formattedStart = trip.start ? new Date(trip.start).toISOString().split('T')[0] : '';

        this.tripForm.patchValue({
          ...trip,
          start: formattedStart
        });
      });
    }
  }

  onSubmit(): void {
    if (this.tripForm.valid) {
      const trip: Trip = this.tripForm.value;
      const token = this.authService.getToken() || ""

      if (this.tripCode) {
        this.tripService.updateTrip(this.tripCode, trip, token).subscribe({
          next: (res) => {
            alert("Trip updated")
            this.router.navigate(['/admin/trips']);
          },
          error: (err: any) => {
            alert("Failed to update !! \n" + err?.message)
          }
        });
      } else {
        this.tripService.addTrip(trip, token).subscribe({
          next:(res) => {
            alert("Trip Added")
            this.router.navigate(['/admin/trips']);
          }, 
          error: (err)=>{
            alert("Failed to Add !! \n" + err?.message)
          }
        });
      }
    }
  }
}
