import { Component, OnInit } from '@angular/core';
import { Trip } from '../../../models/trip';
import { TripDataService } from '../../../services/trip-data.service';
import { Router, RouterModule } from '@angular/router';
import { AuthenticationService } from '../../../services/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-admin-trips',
  imports: [CommonModule, RouterModule],
  templateUrl: './admin-trips.component.html',
  styleUrl: './admin-trips.component.css'
})
export class AdminTripsComponent implements OnInit {
  trips: Trip[] = [];
  constructor(private tripService: TripDataService, private router: Router, private autService: AuthenticationService) { }

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.tripService.getTrips().subscribe(trips => {
      this.trips = trips;
    });
  }

  editTrip(code: string): void {
    this.router.navigate(['/admin/trips', code]);
  }

  deleteTrip(code: string): void {
    const token = this.autService.getToken() || ""
    if (confirm('Are you sure you want to delete this trip?')) {
      this.tripService.deleteTrip(code, token).subscribe(() => {
        this.loadTrips();
      });
    }
  }
}

