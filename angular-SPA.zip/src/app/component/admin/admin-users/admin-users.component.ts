import { Component, OnInit } from '@angular/core';
import { User } from '../../../models/user';
import { TripDataService } from '../../../services/trip-data.service';
import { CommonModule } from '@angular/common';
import { AuthenticationService } from '../../../services/auth.service';

@Component({
  selector: 'app-admin-users',
  imports: [CommonModule],
  templateUrl: './admin-users.component.html',
  styleUrl: './admin-users.component.css'
})
export class AdminUsersComponent implements OnInit {
  users: User[] = [];

  constructor(private tripService: TripDataService, private authService: AuthenticationService) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers() {
    const token = this.authService.getToken() || ""
    this.tripService.getUsers(token).subscribe(
      (data) => {
        this.users = data;
      },
      (error) => {
        console.error('Error fetching users:', error);
      }
    );
  }
}