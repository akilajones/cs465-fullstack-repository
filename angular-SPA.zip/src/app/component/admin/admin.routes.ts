import { Routes } from '@angular/router';
import { AdminTripsComponent } from './admin-trips/admin-trips.component';
import { AdminComponent } from './admin.component';
import { AdminReservationsComponent } from './admin-reservations/admin-reservations.component';
import { AdminUsersComponent } from './admin-users/admin-users.component';
import { AdminTripFormComponent } from './admin-trip-form/admin-trip-form.component';

export const routes: Routes = [
    {
        path: '', component: AdminComponent,
        children: [
            { path: '', pathMatch: 'full', redirectTo: './trips' },
            { path: 'trips', component: AdminTripsComponent },
            { path: 'trips/:id', component: AdminTripFormComponent },
            { path: 'reservations', component: AdminReservationsComponent },
            { path: 'users', component: AdminUsersComponent },
        ]
    },
];

