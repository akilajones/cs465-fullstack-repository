import { Component } from '@angular/core';
import { AuthenticationService } from '../../services/auth.service';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-navbar',
  imports: [RouterModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css',
  standalone: true
})
export class NavbarComponent {
  constructor(private authService: AuthenticationService) { }

  isLoggedIn(): boolean {
    return this.authService.isLoggedIn();
  }

  isAdmin(): boolean {
    return this.authService.isAdmin()
  }

  logout(): void {
    this.authService.logout();
  }
}
