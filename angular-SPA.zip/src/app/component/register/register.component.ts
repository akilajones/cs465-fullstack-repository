import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { AuthenticationService } from '../../services/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule,RouterModule],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  name = '';
  email = '';
  password = '';
  confirmPassword = '';
  agreedToTerms = false;
  errorMessage = '';

  constructor(private authService: AuthenticationService, private router: Router) {}

  register() {
    this.errorMessage = '';
  
    if (this.password !== this.confirmPassword) {
      this.errorMessage = 'Passwords do not match!';
      return;
    }
  
    if (!this.agreedToTerms) {
      this.errorMessage = 'You must agree to the terms and conditions.';
      return;
    }
  
    const userData = { 
      name: this.name, 
      email: this.email, 
      password: this.password, 
      agreedToTerms: this.agreedToTerms 
    };
  
    this.authService.register(userData)
      .then(() => {
        alert('Signup Successful!');
        this.router.navigate(['/login']);
      })
      .catch(err => {
        this.errorMessage = err?.error?.message || 'Signup Failed';
      });
  }
  
}
