import { Component } from '@angular/core';
import { AuthenticationService } from '../../services/auth.service';
import { TripDataService } from '../../services/trip-data.service';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-reservations',
  imports: [CommonModule],
  templateUrl: './reservations.component.html',
  styleUrl: './reservations.component.css'
})
export class ReservationsComponent {
  reservations: any[] = [];
  isLoading: boolean = true;
  errorMessage: string = '';

  constructor(
    private tripService: TripDataService,
    private authService: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.getUserReservations();
  }

  getUserReservations(): void {
    const userEmail = this.authService.getCurrentUser()?.email;
    const token=this.authService.getToken();
    if (!userEmail) {
      this.isLoading = false;
      this.errorMessage = 'User not logged in.';
      return;
    }

    this.tripService.getUserReservations(userEmail,token).subscribe({
      next: (data) => {
        console.log(data);
        this.reservations = data.map(res => ({
          ...res,
          tripImage: res.tripDetails.image 
        }));
        this.isLoading = false;
      },
      error: () => {
        this.errorMessage = 'Error fetching reservations.';
        this.isLoading = false;
      }
    });
  }
}