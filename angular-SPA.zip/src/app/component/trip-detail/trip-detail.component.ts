import { Component, OnInit } from '@angular/core';
import { Trip } from '../../models/trip';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDataService } from '../../services/trip-data.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-trip-detail',
  imports: [CommonModule],
  templateUrl: './trip-detail.component.html',
  styleUrl: './trip-detail.component.css'
})
export class TripDetailComponent implements OnInit {
  trip!: Trip;

  constructor(
    private route: ActivatedRoute,
    private tripService: TripDataService,
    private router: Router
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');
    if (tripCode) {
      this.tripService.getTripByCode(tripCode).subscribe((trip) => {
        this.trip = trip;
      });
    }
  }

  bookTrip() {
    this.router.navigate(['/checkout', this.trip.code]);
  }
  goBack() {
    this.router.navigate(['/']);
  }
}
