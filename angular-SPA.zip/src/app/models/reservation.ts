export interface Reservation {
  _id?: string;
  tripCode: string;
  userEmail: string;
  guests: number;
  status: string;
  createdAt: Date;
}
