
import { Injectable, Inject } from '@angular/core';
import { BROWSER_STORAGE } from '../storage.service';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { TripDataService } from '../services/trip-data.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(
    @Inject(BROWSER_STORAGE) private storage: Storage,
    private tripDataService: TripDataService
  ) { }

  public getToken() {
    return this.storage.getItem('travlr-token');
  }

  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  public login(user: User): Promise<void> {
    return this.tripDataService.login(user)
      .then((authResp: AuthResponse | undefined) => {
        if (authResp && authResp.token) {
          this.saveToken(authResp.token);
        } else {
          throw new Error('Login failed: No token received');
        }
      });
  }

  public register(user: User): Promise<void> {
    return this.tripDataService.register(user)
      .then((authResp: AuthResponse | undefined) => {
        if (authResp && authResp.token) {
          this.saveToken(authResp.token);
        } else {
          throw new Error('Registration failed: No token received');
        }
      });
  }

  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  public isLoggedIn(): boolean {
    const token: string | null = this.getToken();
    if (token && token.includes('.')) {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.exp > (Date.now() / 1000);
    }
    return false;
  }

  public getCurrentUser(): User | null {
    if (this.isLoggedIn()) {
      const token: string | null = this.getToken();
      if (token && token.includes('.')) {
        const { email, name, role } = JSON.parse(atob(token.split('.')[1]));
        return { email, name, role } as User;
      }
    }
    return null;
  }

  isAdmin(): boolean {
    const user = this.getCurrentUser();
    return user?.role === 'admin'
  }

}
