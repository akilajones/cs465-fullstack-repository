import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';
import { Reservation } from '../models/reservation';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private apiUrl = 'http://localhost:9000/api';

  constructor(private http: HttpClient) { }

  public login(user: User) {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, user).toPromise();
  }

  public register(user: User) {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, user).toPromise();
  }

  public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(`${this.apiUrl}/trips`);
  }

  public getTripByCode(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiUrl}/trips/${tripCode}`);
  }

  public addTrip(trip: Trip, token: string): Observable<Trip> {
    return this.http.post<Trip>(`${this.apiUrl}/trips`, trip, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

  public updateTrip(tripCode: string, trip: Trip, token: string): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/trips/${tripCode}`, trip, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

  public deleteTrip(tripCode: string, token: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/trips/${tripCode}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

  public createReservation(tripCode: string, userEmail: any, guests: number, token: string): Observable<any> {
    return this.http.post(`${this.apiUrl}/reservations`,
      { tripCode, userEmail, guests },
      { headers: { Authorization: `Bearer ${token}` } }
    );
  }

  public getUserReservations(userEmail: string, token: any): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/reservations/${userEmail}`, { headers: { Authorization: `Bearer ${token}` } });
  }


  getUsers(token: string): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/users`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }


  getReservations(token: string): Observable<Reservation[]> {
    return this.http.get<Reservation[]>(`${this.apiUrl}/reservations/list-all`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

  updateReservationStatus(reservationId: string, status: string, token: string): Observable<any> {
    return this.http.patch(`${this.apiUrl}/reservations/${reservationId}`, { status }, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  }

}
