// import { Routes } from '@angular/router';

// export const routes: Routes = [];
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { LoginComponent } from './component/login/login.component';
import { RegisterComponent } from './component/register/register.component';
import { TripsListComponent } from './component/trips-list/trips-list.component';
import { TripDetailComponent } from './component/trip-detail/trip-detail.component';
import { ReservationsComponent } from './component/reservations/reservations.component';
import { authGuard } from './guards/auth.guard';
import { TravelComponent } from './component/travel/travel.component';
import { NewsComponent } from './component/news/news.component';
import { CheckoutComponent } from './component/checkout/checkout.component';

export const routes: Routes = [
  { path: '', component: TravelComponent, pathMatch: 'full' }, 
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'news', component: NewsComponent
  },
  { path: 'trips/:tripCode', component: TripDetailComponent },
  { path: 'reservations', component: ReservationsComponent ,canActivate: [authGuard] },
  { path: 'checkout/:tripCode', component: CheckoutComponent ,canActivate: [authGuard] }
];

