import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TripDataService } from '../../services/trip-data.service';
import { Trip } from '../../models/trip';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthenticationService } from '../../services/auth.service';
import { User } from '../../models/user';


@Component({
  selector: 'app-checkout',
  imports: [CommonModule,FormsModule],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent {
  trip: Trip | undefined;
  todayDate: Date = new Date();
  numPersons: number = 1;

  subtotal: number = 0;
  taxAmount: number = 0;
  totalAmount: number = 0;
  token: string | null | undefined;
  email:string | null| undefined;
  constructor(
    private route: ActivatedRoute,
    private tripService: TripDataService,
    private router: Router,
    private auth: AuthenticationService
  ) {}

  ngOnInit(): void {
    this.getTripDetails();
    this.token=this.auth.getToken();
    this.email=this.auth.getCurrentUser()?.email;
  }

   getTripDetails(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');
    if (tripCode) {
      this.tripService.getTripByCode(tripCode).subscribe(
        (data) => {
          this.trip = data;
          this.calculateTotal();
        },
        (error) => {
          console.error('Error fetching trip details:', error);
        }
      );
    }
  }

  calculateTotal(): void {
    if (!this.trip) return;
    
    this.numPersons = Math.max(1, this.numPersons || 1);

    this.subtotal = this.trip.perPerson * this.numPersons;

    this.taxAmount = this.subtotal * 0;

    this.totalAmount = this.subtotal + this.taxAmount;
  }

  confirmBooking(): void {
    if (!this.trip) return;

    this.tripService.createReservation(this.trip.code, this.email, this.numPersons, this.token).subscribe(
      response => {
        alert(`Booking confirmed for ${this.numPersons} person(s). Total Price: $${this.totalAmount}`);
      },
      error => {
        console.error('Error:', error);
        alert("Booking failed. Please try again.");
      }
    );
  }

  goBack(): void {
    this.router.navigate(['/travel']);
  }
}