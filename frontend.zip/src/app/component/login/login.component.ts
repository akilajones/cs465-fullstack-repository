import { Component } from '@angular/core';
import { AuthenticationService } from '../../services/auth.service';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms'; 
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-login',
  imports: [FormsModule,RouterModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  email = '';
  password = '';
  errorMessage: any;

  constructor(private authService: AuthenticationService, private router: Router) {}
  login() {
    this.authService.login({ email: this.email, password: this.password })
      .then(() => {
        this.router.navigate(['/']);
      })
      .catch(err => {
        this.errorMessage = err?.error?.message || 'Login Failed';
      });
  }
}  
