import { Component } from '@angular/core';
import { Trip } from '../../models/trip';
import { TripDataService } from '../../services/trip-data.service';
import { RouterModule } from '@angular/router';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-travel',
  imports: [RouterModule,CommonModule],
  templateUrl: './travel.component.html',
  styleUrl: './travel.component.css'
})
export class TravelComponent {
  trips: Trip[] = []; // ✅ Store fetched trips

  constructor(private tripService: TripDataService, private router:Router) {}

  ngOnInit(): void {
    this.getTrips();
  }

  getTrips(): void {
    this.tripService.getTrips().subscribe(
      (data) => {
        this.trips = data;
      },
      (error) => {
        console.error('Error fetching trips:', error);
      }
    );
  }

  checkout(trip: Trip): void {
    alert(`Proceeding to checkout for ${trip.name}`);
    this.router.navigate(['/checkout', trip.code]); // ✅ Redirect to Checkout Page
  }
}
