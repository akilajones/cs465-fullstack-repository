import { Component } from '@angular/core';

@Component({
  selector: 'app-trip-detail',
  imports: [],
  templateUrl: './trip-detail.component.html',
  styleUrl: './trip-detail.component.css'
})
export class TripDetailComponent {

}
