import { Component } from '@angular/core';

@Component({
  selector: 'app-trips-list',
  imports: [],
  templateUrl: './trips-list.component.html',
  styleUrl: './trips-list.component.css'
})
export class TripsListComponent {

}
