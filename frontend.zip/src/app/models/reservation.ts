export interface Reservation {
    tripCode: string;
    userEmail: string;
    guests: number;
    status: string;
    createdAt: Date;
  }
  