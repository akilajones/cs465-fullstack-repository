export interface Trip {
    code: string;
    name: string;
    length: string;
    start: Date;
    resort: string;
    perPerson: number;
    image: string;
    description: string;
  }
  