import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user';
import { AuthResponse } from '../models/authresponse';
import { Observable } from 'rxjs';
import { Trip } from '../models/trip';

@Injectable({
  providedIn: 'root'
})
export class TripDataService {
  private apiUrl = 'http://localhost:9000/api'; // ✅ Ensure Correct API URL

  constructor(private http: HttpClient) {}

  public login(user: User) {
    return this.http.post<AuthResponse>(`${this.apiUrl}/login`, user).toPromise();
  }

  public register(user: User) {
    return this.http.post<AuthResponse>(`${this.apiUrl}/register`, user).toPromise();
  }

   // ✅ Get All Trips
   public getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(`${this.apiUrl}/trips`);
  }

  // ✅ Get Single Trip by Code
  public getTripByCode(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiUrl}/trips/${tripCode}`);
  }

  // ✅ Create New Trip
  public addTrip(trip: Trip, token: string): Observable<Trip> {
    return this.http.post<Trip>(`${this.apiUrl}/trips`, trip, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

  // ✅ Update Trip
  public updateTrip(tripCode: string, trip: Trip, token: string): Observable<Trip> {
    return this.http.put<Trip>(`${this.apiUrl}/trips/${tripCode}`, trip, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

  // ✅ Delete Trip
  public deleteTrip(tripCode: string, token: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/trips/${tripCode}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
  }

// ✅ Create Reservation
public createReservation(tripCode: string, userEmail: any, guests: number, token: any): Observable<any> {
  return this.http.post(`${this.apiUrl}/reservations`, 
    { tripCode, userEmail, guests }, 
    { headers: { Authorization: `Bearer ${token}` } }
  );
}

// ✅ Get User Reservations
public getUserReservations(userEmail: string): Observable<any[]> {
  return this.http.get<any[]>(`${this.apiUrl}/reservations/${userEmail}`);
}

  
}
