// require('dotenv').config();
// const express = require('express');
// const mongoose = require('mongoose');
// const cors = require('cors');
// const bodyParser = require('body-parser');
// const passport = require('passport');

// const app = express();

// app.use(passport.initialize());
// app.use((req, res, next) => {
//     res.header('Access-Control-Allow-Origin', 'http://localhost:4200');
//     res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
//     res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
//     next();
// });
// app.use(bodyParser.json());

// require('./app_api/models/User');
// require('./app_api/models/Trip');
// require('./app_api/config/passport');

// mongoose.connect(process.env.MONGO_URI, {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
//     serverSelectionTimeoutMS: 5000
// })
//     .then(() => console.log('MongoDB Connected'))
//     .catch(err => console.log(' MongoDB Connection Error:', err));

// const apiRoutes = require('./app_api/routes/index');

// app.use('/api', apiRoutes);

// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//     console.log(`🚀 Server running on port ${PORT}`);
// });
require('dotenv').config();
const express = require('express');
const path = require('path');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const apiRoutes = require('./app_api/routes/index');
const app = express();
const cors = require('cors');


require('./app_api/config/db');
require('./app_api/config/passport');

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
// app.use(express.static(path.join(__dirname, 'public')));
app.use(cors({
    origin: 'http://localhost:4200',  // ✅ Allow Frontend
    methods: 'GET,POST,PUT,DELETE',
    allowedHeaders: 'Content-Type,Authorization'
}));


app.use('/api',apiRoutes);

// Error Handling
// app.use((err, req, res, next) => {
//     if (err.name === 'UnauthorizedError') {
//         res.status(401).json({ "message": err.name + ": " + err.message });
//     }
// });

// ✅ Add Port Here
const PORT = process.env.PORT || 9000;
app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`);
});

module.exports = app;
