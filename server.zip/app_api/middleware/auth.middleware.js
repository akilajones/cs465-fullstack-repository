const jwt = require('jsonwebtoken');

exports.auth = (req, res, next) => {
  try {
        // ✅ Extract Token from Header
        const token = req.header("Authorization")?.replace("Bearer ", "");
        if (!token) return res.status(401).json({ message: "Access Denied! No token provided." });

        // ✅ Verify Token
        const verified = jwt.verify(token, process.env.JWT_SECRET);
        req.auth = verified; // ✅ Maintain `req.auth` for consistency
        next();
    } catch (error) {
        res.status(401).json({ message: "Invalid Token" });
    }
};
