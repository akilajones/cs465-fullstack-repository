const mongoose = require('mongoose');

const reservationSchema = new mongoose.Schema({
    tripCode: { type: String, required: true },
    userEmail: { type: String, required: true },
    guests: Number,
    status: { type: String, default: "Pending" },
    createdAt: { type: Date, default: Date.now }
});

mongoose.model('reservations', reservationSchema);
