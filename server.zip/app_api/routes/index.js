
const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth.middleware');
const authController = require('../controllers/authentication');
const tripsController = require('../controllers/tripController');
const reservationsController = require('../controllers/reservationsController');


router.post('/register', authController.register);
router.post('/login', authController.login);

router.get('/trips', tripsController.tripsList);
router.get('/trips/:tripCode', tripsController.tripsFindByCode);
router.post('/trips',auth, tripsController.tripsAddTrip);
router.put('/trips/:tripCode', tripsController.tripsUpdateTrip);
router.delete('/trips/:tripCode', tripsController.tripsDeleteTrip);

router.post('/reservations',auth, reservationsController.createReservation);
router.get('/reservations/:userEmail', reservationsController.getUserReservations);

module.exports = router;
